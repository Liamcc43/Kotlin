import java.util.Scanner

class User(
    val name: String?,
    val age: Int?,
    val email: String?,
    val address: String?
) {
    fun displayUserInfo() {
        println("Ім'я: ${name ?: "Немає імені"}")
        println("Вік: ${age ?: "Невідомий"}")
        println("Email: ${email ?: "Немає email"}")
        println("Адреса: ${address ?: "Немає адреси"}")
    }
}

fun main() {
    val scanner = Scanner(System.`in`)

    // Зчитування даних про користувача з клавіатури
    println("Введіть ім'я користувача:")
    val name = scanner.nextLine()

    println("Введіть вік користувача (якщо невідомий, натисніть Enter):")
    val ageInput = scanner.nextLine()
    val age = if (ageInput.isBlank()) null else ageInput.toIntOrNull()

    println("Введіть email користувача (якщо немає, натисніть Enter):")
    val email = scanner.nextLine().takeIf { it.isNotBlank() }

    println("Введіть адресу користувача (якщо немає, натисніть Enter):")
    val address = scanner.nextLine().takeIf { it.isNotBlank() }

    // Створення об'єкта користувача з введеними даними
    val user = User(name.takeIf { it.isNotBlank() }, age, email, address)

    // Виведення інформації про користувача, ігноруючи null значення
    println("\nІнформація про користувача:")
    user.displayUserInfo()

    scanner.close()
}
