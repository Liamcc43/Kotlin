import java.util.Scanner
import kotlin.math.PI
import kotlin.math.sqrt

// Батьківський клас
open class GeometricFigure {
    open fun area(): Double {
        return 0.0
    }

    open fun perimeter(): Double {
        return 0.0
    }
}

// Підклас для квадрата
class Square(private val sideLength: Double) : GeometricFigure() {
    override fun area(): Double {
        return sideLength * sideLength
    }

    override fun perimeter(): Double {
        return 4 * sideLength
    }
}

// Підклас для кола
class Circle(private val radius: Double) : GeometricFigure() {
    override fun area(): Double {
        return PI * radius * radius
    }

    override fun perimeter(): Double {
        return 2 * PI * radius
    }
}

// Підклас для трикутника
class Triangle(private val sideA: Double, private val sideB: Double, private val sideC: Double) : GeometricFigure() {
    override fun area(): Double {
        // Використовуємо формулу Герона для обчислення площі трикутника
        val s = perimeter() / 2
        return sqrt(s * (s - sideA) * (s - sideB) * (s - sideC))
    }

    override fun perimeter(): Double {
        return sideA + sideB + sideC
    }
}

fun main() {
    val scanner = Scanner(System.`in`)

    var continueProgram = true

    while (continueProgram) {
        println("Виберіть опцію:")
        println("1. Обчислити площу та периметр квадрата")
        println("2. Обчислити площу та периметр кола")
        println("3. Обчислити площу та периметр трикутника")
        println("4. Вийти з програми")

        // Зчитування вибору користувача
        val choice = scanner.nextInt()

        when (choice) {
            1 -> {
                println("Введіть довжину сторони квадрата:")
                val sideLength = scanner.nextDouble()
                val square = Square(sideLength)
                println("Площа квадрата: ${square.area()}")
                println("Периметр квадрата: ${square.perimeter()}")
            }
            2 -> {
                println("Введіть радіус кола:")
                val radius = scanner.nextDouble()
                val circle = Circle(radius)
                println("Площа кола: ${circle.area()}")
                println("Довжина кола: ${circle.perimeter()}")
            }
            3 -> {
                println("Введіть довжини сторін трикутника (через пробіл):")
                val sideA = scanner.nextDouble()
                val sideB = scanner.nextDouble()
                val sideC = scanner.nextDouble()
                val triangle = Triangle(sideA, sideB, sideC)
                println("Площа трикутника: ${triangle.area()}")
                println("Периметр трикутника: ${triangle.perimeter()}")
            }
            4 -> {
                println("Програма завершує роботу.")
                continueProgram = false
            }
            else -> {
                println("Невірний вибір опції. Будь ласка, спробуйте ще раз.")
            }
        }
    }

    scanner.close()
}
