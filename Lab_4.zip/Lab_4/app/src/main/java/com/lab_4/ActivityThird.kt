package com.lab_4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ActivityThird : AppCompatActivity() {

    private lateinit var buttonBackToMain: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        buttonBackToMain = findViewById(R.id.button_back_to_main)

        buttonBackToMain.setOnClickListener {
            finish() // Navigates back to the previous activity (MainActivity)
        }
    }
}
