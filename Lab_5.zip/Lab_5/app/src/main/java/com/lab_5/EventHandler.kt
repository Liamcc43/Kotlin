package com.lab_5
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class EventHandler {
    fun changeColorOnClick(button: Button) {
        button.setOnClickListener {
            val randomColor = Color.argb(255, Random.nextInt(256), Random.nextInt(256), Random.nextInt(256))
            button.setBackgroundColor(randomColor)
        }
    }

    fun changeNumberOnClick(button: Button) {
        button.setOnClickListener {
            val randomNumber = Random.nextInt(10)
            button.text = randomNumber.toString()
        }
    }

    fun showMessageOnClick(textView: TextView, message: String, context: Context) {
        textView.setOnClickListener {
            // Створення і показ системного повідомлення (Toast)
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun makeImageDraggable(imageView: ImageView) {
        imageView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    Log.d("TouchEvent", "ACTION_DOWN: ${event.rawX}, ${event.rawY}")
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    Log.d("TouchEvent", "ACTION_MOVE: ${event.rawX}, ${event.rawY}")
                    imageView.x = event.rawX - view.width / 2
                    imageView.y = event.rawY - view.height / 2
                    true
                }
                MotionEvent.ACTION_UP -> {
                    Log.d("TouchEvent", "ACTION_UP")
                    true
                }
                else -> false
            }
        }
    }
    fun handleEditTextChanges(editText: EditText, textView: TextView) {
        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Операції, які виконуються перед зміною тексту
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Операції, які виконуються під час зміни тексту
                val newText = s?.toString() ?: ""
                textView.text = newText // Відображення тексту у TextView
            }

            override fun afterTextChanged(s: Editable?) {
                // Операції, які виконуються після зміни тексту
            }
        })
    }

}
