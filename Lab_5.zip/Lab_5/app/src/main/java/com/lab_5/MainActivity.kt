package com.lab_5
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.lab_5.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val eventHandler = EventHandler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val colorButton: Button = binding.colorButton
        val changeNumberButton: Button = binding.changeNumberButton
        val textView: TextView = binding.textView
        val draggableImageView: ImageView = binding.draggableImageView
        val editText: EditText = binding.editText

        // Додайте обробку змін тексту у EditText
        eventHandler.handleEditTextChanges(editText, textView)
        // Обробка кліку для зміни коліру кнопки
        eventHandler.changeColorOnClick(colorButton)

        // Обробка кліку для зміни цифри на кнопці
        eventHandler.changeNumberOnClick(changeNumberButton)

        // Обробка кліку для відображення системного повідомлення
        eventHandler.showMessageOnClick(textView, "Це текстове повідомлення!", this)

        // Обробка переміщення тексту по тапу
        eventHandler.makeImageDraggable(draggableImageView)
    }
}
