package com.lab_7_8

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.lab_7_8.R
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupActionBarWithNavController

class MainActivity : AppCompatActivity() {

    private lateinit var navHostFragment: NavHostFragment;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Знаходимо NavController
        this.navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment

        findViewById<Button>(R.id.button_to_third).setOnClickListener {
            val navController = navHostFragment.navController
            navController.navigate(R.id.thirdFragment)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Обробляємо натискання кнопки "назад" на пристрої
        val navController = navHostFragment.navController
        if (!navController.popBackStack()) {
            super.onBackPressed()
        }
    }
}

