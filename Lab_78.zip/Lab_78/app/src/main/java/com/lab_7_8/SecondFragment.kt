package com.lab_7_8

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.lab_7_8.R
import androidx.navigation.fragment.findNavController

class SecondFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Отримання переданого параметра з Bundle
        val message = "Received message: " + arguments?.getString("message")

        // Встановлення тексту в TextView для відображення отриманого повідомлення
        view.findViewById<TextView>(R.id.text_view_received_message).text = message

        // Обробник подій для кнопки
        view.findViewById<Button>(R.id.button_to_first).setOnClickListener {
            // Навігація до першого фрагменту
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }
    }
}
